package com.first_assignement;
import java.util.*;

public class Assignement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 2 Numbers: ");
		float firstNumber = scan.nextFloat();
		float secondNumber = scan.nextFloat();
		System.out.println("The Addition of "+firstNumber+" and "+secondNumber+" is: "+(firstNumber+secondNumber));
		System.out.println("The Substraction of "+firstNumber+" and "+secondNumber+" is: "+(firstNumber-secondNumber));
		System.out.println("The Multiplication of "+firstNumber+" and "+secondNumber+" is: "+(firstNumber*secondNumber));
		System.out.println("The Division of "+firstNumber+" and "+secondNumber+" is: "+(firstNumber/secondNumber));
		System.out.println("The Reminder for "+firstNumber+" / "+secondNumber+" is: "+(firstNumber%secondNumber));
		scan.close();
	}

}
