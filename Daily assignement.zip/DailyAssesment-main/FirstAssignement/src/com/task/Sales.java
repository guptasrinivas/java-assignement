package com.task;

public class Sales {
	public static boolean checkProductId(int value) {
		if (value >= 10001 || value <= 99999) {
			return true;
		}
		return false;
	}

	public String getAmount(char size) {
		switch (size) {
		case 'S': {
			return "30$";
		}
		case 'M': {
			return "50$";
		}
		default:
			return "80$";
		}

	}
}
