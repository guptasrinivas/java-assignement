package com.task;

public class Test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sales s = new Sales();
		System.out.println(Sales.checkProductId(99999));
		System.out.println(s.getAmount('M'));
	}

}
