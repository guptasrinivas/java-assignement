package com.sudeb;

//POJO(Plain Old Java Object)
public class Employee {
	private long empID;
	private String name, address, phone;
	private boolean salaryPaid;
	
	
}
