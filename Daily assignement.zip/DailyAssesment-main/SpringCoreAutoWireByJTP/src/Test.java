import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.data.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("data.xml");  
		    A a=(A) context.getBean("a");  
		    a.display();  
	}

}
