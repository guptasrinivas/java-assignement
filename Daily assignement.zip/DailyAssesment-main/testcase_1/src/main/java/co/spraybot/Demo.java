package co.spraybot;

public class Demo {

}
