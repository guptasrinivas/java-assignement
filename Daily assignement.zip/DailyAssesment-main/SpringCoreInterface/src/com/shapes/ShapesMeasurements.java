package com.shapes;

public interface ShapesMeasurements {
	public Double area();
	public Double volume();
	
	
}
