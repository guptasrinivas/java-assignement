package SetterInject;

public class Predator implements FootballBoots{

	public Predator() {}
	
	@Override
	public void wearBoots() {
		// TODO Auto-generated method stub
		System.out.println("I am wearing Adidas Predator Boots.");
	}
	
}
