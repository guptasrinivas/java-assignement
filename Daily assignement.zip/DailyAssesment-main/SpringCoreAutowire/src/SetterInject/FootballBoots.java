package SetterInject;

public interface FootballBoots {
	void wearBoots();
}
