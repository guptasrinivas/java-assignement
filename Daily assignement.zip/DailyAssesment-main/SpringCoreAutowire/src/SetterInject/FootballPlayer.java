package SetterInject;

public class FootballPlayer implements player{
	private int shirtNumber;

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("I am Playing with shirt number "+shirtNumber+".");
	}

	public FootballPlayer(int shirtNumber) {
		super();
		this.shirtNumber = shirtNumber;
	}

	
}
