package SetterInject;

public interface player {
	void play();
}
