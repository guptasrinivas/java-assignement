class PolyA{
	
	public void fun1(int x){    
		System.out.println("The value of class A is : " + x);
    }
	
    public void fun1(int x,int y){
    	System.out.println("The value of class B is : "+x +" and "+ y);
    }
}
public class Polymorphism {
	 public static void main(String[] args){    
		 PolyA obj=new PolyA();
		 
		 // Here compiler decides that fun1(int) is to be called and "int" will be printed.
		 obj.fun1(2);
	     
		 // Here compiler decides that fun1(int,int) is to be called and "int and int" will be printed.
		 obj.fun1(2,3);    
		 }
}
