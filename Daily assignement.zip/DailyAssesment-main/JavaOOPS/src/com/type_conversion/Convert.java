package com.type_conversion;

public class Convert {
	public static void main(String[ ] args)
    {
        int i;
        char c = 'a';
              i = (int)c;
        System.out.println(i);
              i = 5;
              c = (char)i;
        System.out.println(c);
    }
}
