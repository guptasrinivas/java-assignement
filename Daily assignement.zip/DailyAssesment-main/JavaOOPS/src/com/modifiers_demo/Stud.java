package com.modifiers_demo;

public class Stud {
	   public static void main(String args[ ])
	   {    Student s=new Student();
	           s.read(); s.calculate();
	s.display();
	   }
}
