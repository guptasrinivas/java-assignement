package com.modifiers_demo;

public class pyramid {
	public static void main(String args[ ])
    {    int i,j;
        System.out.println("Displaying Numbers:");
        for(i=1;i< 10;i++)
        {    for(j=1;j< i+1;j++)
            {
                System.out.print(" " +i);
            }
            System.out.println();
        }
    }
}
