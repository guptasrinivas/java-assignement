package com.static_demo;

public class Static2 {
	 static int a=10;
     static int b=20;
     static void call()
     {
         System.out.println("Value1="+a);
     }
 }
