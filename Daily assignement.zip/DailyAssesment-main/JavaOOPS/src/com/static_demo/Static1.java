package com.static_demo;

public class Static1 {
	static int c=0;
    void increment()
    {    c++;
    }
    void display()
    {    System.out.println("Value="+c);
    }
 }
