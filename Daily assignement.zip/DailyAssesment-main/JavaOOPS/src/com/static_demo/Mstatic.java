package com.static_demo;

public class Mstatic {
	 public static void main(String args[ ])
     {    
		 Static1 s=new Static1();
         Static1 s1=new Static1();
         Static1 s2=new Static1();
         s.increment();
         s1.increment();
         s2.increment();
         s.display();
         s1.display();
         s2.display();
     }

}
