package com.static_demo;

public class CubeStaticTest {

    public static void main(String args[ ])
    {
    	Cube c =new Cube();
    	System.out.println("Number of Cube objects = "+ Cube.numOfCubes);
    	System.out.println("Number of Cube objects = "+ Cube.getNoOfCubes());
    }
}
