package com.static_demo;

public class Mstatic1 {
	     public static void main(String args[ ])
	     {
	         Static2.call();
	         System.out.println("Value2="+Static2.b);
	     }

}
