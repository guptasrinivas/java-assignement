package com.operators_demo;

public class EquityAndRelationalOperators {
	public static void main(String[] args)
    {        
		int x = 5;
        int y = 10;
             
        if(x == y)
           System.out.println("value of x is equal to the value of y");
             
        if(x != y)
           System.out.println("value of x is not equal to the value of y");
           
        if(x > y)
           System.out.println("value of x is grater then the value of y");
        
        if(x < y)
           System.out.println("value of x is less then the value of y");
        
        if(x >= y)
             System.out.println("value of x is grater then or equal to the value of y");
        
        if(x <= y)
               System.out.println("value of x is less then or equal to the value of y");
     }
}
