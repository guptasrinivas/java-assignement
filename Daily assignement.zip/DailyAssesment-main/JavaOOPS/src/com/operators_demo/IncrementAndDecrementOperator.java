package com.operators_demo;

public class IncrementAndDecrementOperator {
	public static void main (String args[ ]){
        for (int i = 0; i < 50; i++){
            System.out.println(i);
          }
     }
}

//Java has decrement operators
class Count
{
   public static void main (String args[ ])
    {
          for (int i = 50; i > 0; i--){
        	  System.out.println(i);
          }

    }
}
