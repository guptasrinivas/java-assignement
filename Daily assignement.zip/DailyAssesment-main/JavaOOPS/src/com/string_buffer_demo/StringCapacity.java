package com.string_buffer_demo;

public class StringCapacity {
	public static void main(String args[ ])
    {
    StringBuffer s1,s2,s3;
    s1=new StringBuffer(); // Each StringBuffer Contains 16 Bits of Memory
    s2=new StringBuffer ("I LOVE MY PLANET");
    s3=new StringBuffer(50);
    System.out.println(s1.capacity());
    System.out.println(s2.capacity());
    System.out.println(s3.capacity());
    System.out.println(s1.capacity()+s2.capacity()+s3.capacity());
    }
}
