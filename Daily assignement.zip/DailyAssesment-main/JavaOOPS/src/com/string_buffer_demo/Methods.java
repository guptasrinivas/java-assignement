package com.string_buffer_demo;

public class Methods {
	 public static void main(String [ ]args)
     {
         String s=new String("SRIVENKATESWARA");
         StringBuffer stb = new StringBuffer(s);
         stb.reverse();
         System.out.println("Reverse is:"+stb);
         System.out.println("capacity is:"+stb.capacity());
         System.out.println("character at:"+stb.charAt(3));
         System.out.println("delete 2,4:"+stb.delete(2,4));
         System.out.println("delete char at:"+stb.deleteCharAt(3));
         System.out.println("Insert at:"+stb.insert(2,'o'));
         System.out.println("replace:"+stb.replace(2,3,"sr"));
     }
}
