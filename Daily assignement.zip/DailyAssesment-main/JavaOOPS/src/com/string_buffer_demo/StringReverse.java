package com.string_buffer_demo;

public class StringReverse {
	  public static void main(String args[ ])
      {
          StringBuffer s=new StringBuffer("abcdefg"); 
          System.out.println(s.reverse());
      }
}
