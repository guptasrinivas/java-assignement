package com.assigements;

public class Trail {
	    public static void main(String args[])
	    {
	        Student s1 = new Student(101,"Gagan");
	        Student s2 = new Student(102,"Raman");
	        s1.display();  // call the display function using the s1 object
	        s2.display();   // call the display function using the s2 object
	    }
}