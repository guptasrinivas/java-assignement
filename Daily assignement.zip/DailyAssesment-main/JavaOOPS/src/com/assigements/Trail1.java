package com.assigements;

public class Trail1 {
	public static void main(String args[])
    {

    }
}
