package com.super_class;

public class ThreeOverloaded extends Object{
	void m(){
		System.out.println("m()");
          }
}
    
class ThreeOverloadedExtend extends ThreeOverloaded
    {    public void m(int x)
        {    System.out.println("m(int x)");
          }
         public void m(String y)
        {    System.out.println("m(String y)");
          }
}
