package com.super_class;

public class DemoMain { 
       public static void main(String args [ ])
        {   
            extend obj=new extend();
        }
}
