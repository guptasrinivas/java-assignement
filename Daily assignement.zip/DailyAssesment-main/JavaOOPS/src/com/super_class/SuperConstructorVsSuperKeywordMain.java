package com.super_class;

//Class 3
// Main class
// Main driver method

public class SuperConstructorVsSuperKeywordMain {
	public static void main(String[] args) {
		// Creating an object of child class
		Car small = new Car();

		// Calling out method defined inside child class
		small.display();

		// Creating object of subclass
		// inside main() method
		Student s = new Student();
	}
}
