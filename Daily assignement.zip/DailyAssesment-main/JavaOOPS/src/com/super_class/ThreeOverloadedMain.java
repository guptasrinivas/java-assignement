package com.super_class;

public class ThreeOverloadedMain {
	public static void main(String[ ] args)
    {    ThreeOverloadedExtend var = new ThreeOverloadedExtend();
            var.m();
            var.m(3);
            var.m("String");
      }
}
