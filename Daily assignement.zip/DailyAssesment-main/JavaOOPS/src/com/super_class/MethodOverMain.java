package com.super_class;

public class MethodOverMain {
	public static void main(String [ ]args)
    {
        MethodOver mo = new MethodOver();
        mo.show();
        mo.show(121);
        mo.show(4,5);
        mo.show(2.3f,4);
    }
}
