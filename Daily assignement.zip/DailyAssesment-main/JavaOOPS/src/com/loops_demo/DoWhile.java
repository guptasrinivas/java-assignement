package com.loops_demo;

public class DoWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count = 1;
		System.out.println("Printing NUmbers from 1 to 10.");
		
		do {
			System.out.println(count++);
		} while(count <= 10);
	}

}
