package com.loops_demo;

public class ForLooop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Printing Numbers from 1 to 10.");
		
		for (int i = 1; i <=10; i++) {
			System.out.println(i);
		}
		
	}

}
