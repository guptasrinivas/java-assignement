package com.loops_demo;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int count = 1;
         System.out.println ("Printing Numbers from 1 to 10");
         
         while( count <= 10) {
                 System.out.println(count++);
         }
	}

}
