package com.statements_demo;

public class SwitchCase {

	public static void main (String[]args) {
		int month = 10;
		switch(month) {
		case 1: 
			System.out.println("Jan");
			break;
			
		case 2:
			System.out.println("Feb");
			break;
			
		case 3:
			System.out.println("Mar");
			break;
			
		case 4: case 5: case 6: case 7: case 8: case 9:
			System.out.println("After March");
			break;
			
		default:
			System.out.println("Invalid Entry");
			break;
		}
	}
}
