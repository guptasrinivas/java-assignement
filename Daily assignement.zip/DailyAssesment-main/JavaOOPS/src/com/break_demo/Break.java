package com.break_demo;

public class Break {
	public static void main(String[ ] args){
            System.out.println ("Numbers 1 - 10");
            for (int i = 1; ; ++i){
                    if (i == 11)
                        break;
                    // Rest of loop body skipped when i is even
                    System.out.println(i + "\t");
            }
        }
}
