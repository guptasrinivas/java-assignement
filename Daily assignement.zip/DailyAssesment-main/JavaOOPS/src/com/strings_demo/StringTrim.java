package com.strings_demo;

public class StringTrim {
	 public  static void main(String args[])
     {
         String s="     PLANET      ";
         System.out.println(s.trim());
     }
}
