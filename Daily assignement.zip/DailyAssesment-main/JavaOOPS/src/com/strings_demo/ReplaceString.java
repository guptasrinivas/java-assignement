package com.strings_demo;

public class ReplaceString {
	 public  static void main(String args[ ])
     {
         String s="India ";
         System.out.println(s.replace(' ','n'));
     }
}
