package com.strings_demo;

public class CompareStrings {
	public static void main(String[ ] args)
    {            if("String".substring(0) == "String")
                    System.out.println("Equal");
                else
                    System.out.println("Not Equal");      
            if("String".substring(0,6) == "String")
                    System.out.println("Equal");
        else
                    System.out.println("Not Equal");
        if("String".replace('t','t') == "String")
                    System.out.println("Equal");
        else
                    System.out.println("Not Equal");
                if("String".trim() == "String")
            System.out.println("Equal");
                else
                    System.out.println("Not Equal");
                if("String".substring(0,4) == "Stri")
                    System.out.println("Equal");
                else
                    System.out.println("Not Equal");
        if("String".replace('t','T') == "STring")
                    System.out.println("Equal");
                else
                    System.out.println("Not Equal");
    }
}
