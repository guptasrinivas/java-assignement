package com.strings_demo;

public class ToUpperCase {
	public  static void main(String args[])
    {
        String s="i love my planet";
        System.out.println(s.toUpperCase()); 
        }
}
