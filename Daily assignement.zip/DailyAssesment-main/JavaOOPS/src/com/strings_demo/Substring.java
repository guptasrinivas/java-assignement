package com.strings_demo;

public class Substring {
	public  static void main(String args[])
    {
        String s="I Love My Planet";
        System.out.println(s.substring(2,6));
    }
}
