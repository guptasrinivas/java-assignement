package com.strings_demo;

public class ToLowerCase {
	public  static void main(String args[])
    {
        String s="I LOVE MY Country";
        System.out.println(s.toLowerCase());
    }
}
