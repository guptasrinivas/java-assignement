package com.strings_demo;

public class StringConcat {
	public  static void main(String args[ ])
    {
        String s="I Love ";
        String s1=s.concat("My Planet");
        System.out.println(s1);
    }
}
