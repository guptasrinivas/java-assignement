package com.strings_demo;

public class FindLength {
	 public static void main(String args[ ])
     {
         String s="I love";
         String s1="My Planet";
         System.out.println(s.length());
         System.out.println(s1.length());
     }
}
