package com.parameters_demo;

public class CallByValue {
	void meth(int i,int j)
    {
        i=i*2;
        j=j/2;
        System.out.println(i +" "+j);
    }
}
