package com.parameters_demo;

public class cbv {
	public static void main (String args [ ])
    {
        CallByValue t=new CallByValue();
        int a=4,b=7;
        System.out.println ("Before calling a="+a+"b="+b);
        t.meth(a,b);
        System.out.println ("After calling a="+a+"b="+b);
    }
}
