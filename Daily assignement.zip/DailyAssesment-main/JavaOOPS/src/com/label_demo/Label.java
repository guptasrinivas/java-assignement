package com.label_demo;

public class Label {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AAA:{
			System.out.println("Block AAA");
    
            BBB:{
            	System.out.println("Block BBB");
        
                  CCC:{
                	  if(true)
                		  break BBB;
                	  }        
                  System.out.println("Out of Block CCC");           
            }        
            System.out.println("Out of Block BBB");        
		}        
		System.out.println("Out of Block AAA");
	}

}
