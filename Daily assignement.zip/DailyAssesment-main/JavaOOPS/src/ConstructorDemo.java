
public class ConstructorDemo {
	int pagenumber;
    String title;
    String publisher;
    float price;
    public void Book() {
    	
    } //constructor
    
    public String setBookTitle(String title) {
    	return this.title;
    }
}
