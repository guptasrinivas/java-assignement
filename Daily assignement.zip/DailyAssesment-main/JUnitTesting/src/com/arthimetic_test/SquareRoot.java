package com.arthimetic_test;

public class SquareRoot {
	public double findSquareroot(double num){
		   return Math.sqrt(num);       
		}   
}
