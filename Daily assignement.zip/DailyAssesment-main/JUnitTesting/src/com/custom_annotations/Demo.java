package com.custom_annotations;

public class Demo {
	@Fast
	public void test() {
	
	}
}
