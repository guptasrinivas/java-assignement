package com.calculator_test_one_by_one;

public class Calculator {
	public int add(int x, int y) {
		return x + y;
	}
}
