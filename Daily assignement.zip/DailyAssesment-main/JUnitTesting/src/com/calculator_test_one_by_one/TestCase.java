package com.calculator_test_one_by_one;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class TestCase {
	
	@Test
	   public void testAdd() {
	      //test data
	      int num = 5;
	      String temp = null;
//	      String temp = "Not Null";
	      String str = "Junit is working fine";
	 
	      //check for equality
	      assertEquals("Junit is working fine", str);

	      //check for false condition
	      assertFalse(num > 6);
	 
	      //check for not null value
	      assertNotNull(temp);
	      
	      //Check for null value
//	      assertNull(temp);
	   }
	
	@Test
	public void testNum() {
		int num = 5;
		
		//Check for True Condition
		assertTrue(num == 5);
	}
	
}
