import org.junit.Assert;
import org.junit.Test;


class Demo {

	@Test
    public void myTest() {
        //assertEquals(10, 10);
        Assert.assertEquals("hello", "Hello");
    }

}
